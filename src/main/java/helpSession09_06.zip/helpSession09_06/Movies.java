package helpSession09_06;

import com.google.gson.Gson;
import jsonFiles.People;

import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;

/** A class that represents a collection of movies. */
public class Movies {
    // FILL IN CODE
    // Store information about movies in a map where the key is the name of the director,
    // and the value is a set of movies they directed



}
