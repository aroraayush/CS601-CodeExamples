package helpSession09_06Solution;

import com.google.gson.Gson;

import java.io.FileReader;
import java.io.IOException;
import java.util.*;

/** A class that represents a collection of movies. */
public class Movies {

    private List<Movie> movies;
    private Map<String, SortedSet<Movie>> moviesMap;

    public Movies() {
        movies = new ArrayList();
        moviesMap = new HashMap();
    }

    // FILL IN CODE
    // Store information about movies in a map where the key is the name of the director,
    // and the value is a set of movies they directed

    public void loadMovies(String file) {
        Gson gson = new Gson();

        try (FileReader br = new FileReader(file)) {
            Movies allMovies = gson.fromJson(br, Movies.class);
            movies = allMovies.movies;
            System.out.println(movies.size());
            //System.out.println(allMovies);
            for (int i = 0; i < movies.size(); i++) {
                Movie m = movies.get(i);
                System.out.println(m);
                Set<String> dirs = m.getDirectors();
                Iterator<String> it = dirs.iterator();
                while (it.hasNext()) {
                    String dir = it.next();
                    if (!moviesMap.containsKey(dir)) {
                        moviesMap.put(dir, new TreeSet());
                    }
                    moviesMap.get(dir).add(m);
                }

            }

        } catch (IOException e) {
            System.out.println("Could not read the file: " + e);
        }
    }


    public SortedSet<Movie> getMovies(String key) {
        System.out.println(moviesMap.containsKey(key));
        if (!moviesMap.containsKey(key)) {
            System.out.println("No such name");
            return null;
        }
        SortedSet<Movie> sm = moviesMap.get(key);
        SortedSet unmodMovies= Collections.unmodifiableSortedSet(sm);
        return unmodMovies;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        System.out.println(movies.size());
        for (int i = 0; i < movies.size(); i++) {
            sb.append(movies.get(i));
            sb.append(System.lineSeparator());
        }
        return sb.toString();
    }
}
