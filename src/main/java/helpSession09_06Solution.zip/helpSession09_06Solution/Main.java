package helpSession09_06Solution;

import java.util.Scanner;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

public class Main {
    public static void main(String[] args) {
        // FILL IN CODE:
        // Open json file given by the first command line argument
        // Parse it and load data into Movies
        // Allow the user to type the name of the director and show all movies by this director
        // The search should be efficient.
        // Movie should be sorted by year (in ascending order)
        if (args.length != 1)
            throw new IllegalArgumentException();

        String filename = args[0];
        Movies movies = new Movies();
        movies.loadMovies(filename);

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the director's name");
        String name = sc.nextLine();
        SortedSet<Movie> moviesDir = movies.getMovies(name);
        System.out.println(moviesDir);
    }
}
