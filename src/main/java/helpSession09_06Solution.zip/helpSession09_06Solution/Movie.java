package helpSession09_06Solution;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

// Represents a single movie; should store title, year and directors
public class Movie implements Comparable<Movie> {
    // FILL IN CODE
    private String title;
    private int year;
    private Set<String> directors;

    public Movie(String title, int year) {
        this.title = title;
        this.year = year;
        directors = new HashSet();
    }

    public void addDirector(String name) {
        directors.add(name);

    }

    public String toString() {
        return title + " " + year + "; " + directors;
    }

    public Set getDirectors() {
        Set unmodDirectors= Collections.unmodifiableSet(directors);
        return unmodDirectors;
    }

    @Override
    public int compareTo(Movie m2) {
        return ((Integer)year).compareTo(m2.year);

    }
}
